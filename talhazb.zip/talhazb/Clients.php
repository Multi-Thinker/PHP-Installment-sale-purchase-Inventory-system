<?php
$functionsINNER=TRUE;
$functions['TRADITIONAL']=1;
include "config.php"; 
$userInfo = userInfo();
?>
<?php include "tHeader.php"; ?>
<style>
#img-upload{
	height: auto !important;
}
.drawable {
  max-width: 200px;
  border: 1px solid black;
  border-radius: 5px;
}
.server{
	position:absolute;
}
.absolute{
	float: left;
    position: absolute;
    top: 0;
    overflow: hidden;
    width: 100%;
	min-height: 100%;
    background: white;
    align-items: center;
    text-align: center;
    margin: 0 auto;
    padding: 20px;
}
</style>

<h1 class="page-header">Clients</h1> 
<center><a href="Client.php"><button class="btn btn-info btn-lg">ADD NEW</button></a></center>
<hr>
		
	<?=log_message();?>
<div class="server">
	<h2>Records of Clients</h2>
	
	<table class="table sort_table table-striped">
		<thead>
			<tr>
				<th>ACC #</th>
				<th>Picture</th>
				<th>Name</th>
				<th>Designation</th>
				<th>Father</th>
				<th>Guarantor</th>
				<th>Client's Phone</th>
				<th>Guarantor's Phone</th>
				<th>Sale in progress</th>
				<th>Action</th>
			</tr>
		</thead>
		<tbody>

		
	<?php 
		$clients = mysqli_query($con,"SELECT IFNULL((select count(id) FROM transactions tt where tt.client_id=c.id and tt.type='2' and tt.dispute='0' AND status='0'),0) as selling, c.permanent_address as paddr, c.address as addr, c.cnic, c.account_number as acc, c.id as cid, c.name as client, g.name as guarantor, c.phone as client_phone, g.phone as gaurantor_phone, c.occupation as designation, c.image as av, c.father_name as father FROM clients c, GUARANTOR g where c.guarantor_id=g.id");
		while($result = mysqli_fetch_array($clients)){
			$cnic = dbOUT($result['cnic']);
			// 3310293296339
			// if()
			// $cnic[4] = $cnic[4]."-";
			// $cnic[11] = $cnic[11]."-";
			?>
			<tr>
				<td><?=dbOUT($result['acc'])?></td>
				<td>
					<?php 
					$av = dbOUT($result['av']);
					$addr = dbOUT($result['addr']);
					$pddr = dbOUT($result['paddr']);
					if($av==""){
						echo "<a href='javascript:void(0)' class='showAble' data-cnic='".$cnic."' data-addr='".$addr."' data-paddr='".$pddr."' data-src=''>NO IMAGE AVAILABLE</a>";
					}else{
						?>
						<a href="javascript:void(0);" class="showAble" data-src="uploads/image/<?=$av?>" data-cnic="<?=$cnic?>" data-addr="<?=$addr?>" data-paddr="<?=$pddr?>">Click to view image</a>
						<?php 
					}
					?>
				</td>
				<td><?=dbOUT($result['client'])?></td>
				<td><?=dbOUT($result['designation'])?></td>
				<td><?=dbOUT($result['father'])?></td>
				<td><?=dbOUT($result['guarantor'])?></td>
				<td><?=dbOUT($result['client_phone'])?></td>
				<td><?=dbOUT($result['gaurantor_phone'])?></td>
				<td><a href="Transactions.php?type=sales&party=<?=dbOUT($result['cid'])?>&client=true">
					<?=$result['selling'];?>
				</a>
				<td>
					<a href="editClient.php?UID=<?=$result['cid']?>&csrf_token=<?=$csrf_token?>">
						EDIT
					</a>
					<br>
					<a href="javascript:void(0)" onclick="getConfirmation('Are you sure you want to perform this action, data loss is unrecoverable!','<?=$result['cid']?>','<?=$av?>','Save.php?function=deleteClient&csrf_token=<?=$csrf_token?>&UID=<?=$result['cid']?>&avatar=<?=$av?>')">DELETE
					</a>
				</td>
			</tr>
			<?php 
		}
	?>
	</tbody>
			<tr>
				<th>ACC #</th>
				<th>Picture</th>
				<th>Name</th>
				<th>Designation</th>
				<th>Father</th>
				<th>Guarantor</th>
				<th>Client's Phone</th>
				<th>Guarantor's Phone</th>
				<th>Action</th>
			</tr>
	</table>
	<div class="hidden absolute">
		<img class="drawable" src="data:image/gif;base64,R0lGODlhEAAQAPIAAP///wAAAMLCwkJCQgAAAGJiYoKCgpKSkiH/C05FVFNDQVBFMi4wAwEAAAAh/hpDcmVhdGVkIHdpdGggYWpheGxvYWQuaW5mbwAh+QQJCgAAACwAAAAAEAAQAAADMwi63P4wyklrE2MIOggZnAdOmGYJRbExwroUmcG2LmDEwnHQLVsYOd2mBzkYDAdKa+dIAAAh+QQJCgAAACwAAAAAEAAQAAADNAi63P5OjCEgG4QMu7DmikRxQlFUYDEZIGBMRVsaqHwctXXf7WEYB4Ag1xjihkMZsiUkKhIAIfkECQoAAAAsAAAAABAAEAAAAzYIujIjK8pByJDMlFYvBoVjHA70GU7xSUJhmKtwHPAKzLO9HMaoKwJZ7Rf8AYPDDzKpZBqfvwQAIfkECQoAAAAsAAAAABAAEAAAAzMIumIlK8oyhpHsnFZfhYumCYUhDAQxRIdhHBGqRoKw0R8DYlJd8z0fMDgsGo/IpHI5TAAAIfkECQoAAAAsAAAAABAAEAAAAzIIunInK0rnZBTwGPNMgQwmdsNgXGJUlIWEuR5oWUIpz8pAEAMe6TwfwyYsGo/IpFKSAAAh+QQJCgAAACwAAAAAEAAQAAADMwi6IMKQORfjdOe82p4wGccc4CEuQradylesojEMBgsUc2G7sDX3lQGBMLAJibufbSlKAAAh+QQJCgAAACwAAAAAEAAQAAADMgi63P7wCRHZnFVdmgHu2nFwlWCI3WGc3TSWhUFGxTAUkGCbtgENBMJAEJsxgMLWzpEAACH5BAkKAAAALAAAAAAQABAAAAMyCLrc/jDKSatlQtScKdceCAjDII7HcQ4EMTCpyrCuUBjCYRgHVtqlAiB1YhiCnlsRkAAAOwAAAAAAAAAAAA==" />
		<center><a href="javascript:void(0)" class="Close">Close</a></center>
	</div>
</div>
<?php include "tFooter.php"; ?>
<script>
$(function(){
	$(".showAble").click(function(){
		$(".drawable").attr("src",$(this).attr("data-src"));
		$cnic = $(this).attr("data-cnic");
		$addr = $(this).attr("data-addr");
		$paddr = $(this).attr("data-paddr");
		var $image = $(".drawable");
		var $downloadingImage = $("<img>");
		$downloadingImage.load(function(){
			if($(this).attr("src")!=""){
		  		$image.attr("src", $(this).attr("src"));	
			}else{
				$image.attr("src","data:image/gif;base64,R0lGODlhEAAQAPIAAP///wAAAMLCwkJCQgAAAGJiYoKCgpKSkiH/C05FVFNDQVBFMi4wAwEAAAAh/hpDcmVhdGVkIHdpdGggYWpheGxvYWQuaW5mbwAh+QQJCgAAACwAAAAAEAAQAAADMwi63P4wyklrE2MIOggZnAdOmGYJRbExwroUmcG2LmDEwnHQLVsYOd2mBzkYDAdKa+dIAAAh+QQJCgAAACwAAAAAEAAQAAADNAi63P5OjCEgG4QMu7DmikRxQlFUYDEZIGBMRVsaqHwctXXf7WEYB4Ag1xjihkMZsiUkKhIAIfkECQoAAAAsAAAAABAAEAAAAzYIujIjK8pByJDMlFYvBoVjHA70GU7xSUJhmKtwHPAKzLO9HMaoKwJZ7Rf8AYPDDzKpZBqfvwQAIfkECQoAAAAsAAAAABAAEAAAAzMIumIlK8oyhpHsnFZfhYumCYUhDAQxRIdhHBGqRoKw0R8DYlJd8z0fMDgsGo/IpHI5TAAAIfkECQoAAAAsAAAAABAAEAAAAzIIunInK0rnZBTwGPNMgQwmdsNgXGJUlIWEuR5oWUIpz8pAEAMe6TwfwyYsGo/IpFKSAAAh+QQJCgAAACwAAAAAEAAQAAADMwi6IMKQORfjdOe82p4wGccc4CEuQradylesojEMBgsUc2G7sDX3lQGBMLAJibufbSlKAAAh+QQJCgAAACwAAAAAEAAQAAADMgi63P7wCRHZnFVdmgHu2nFwlWCI3WGc3TSWhUFGxTAUkGCbtgENBMJAEJsxgMLWzpEAACH5BAkKAAAALAAAAAAQABAAAAMyCLrc/jDKSatlQtScKdceCAjDII7HcQ4EMTCpyrCuUBjCYRgHVtqlAiB1YhiCnlsRkAAAOwAAAAAAAAAAAA==");
			}
		});
		$downloadingImage.attr("src", $(this).attr("data-src"));
		$(".absolute").removeClass("hidden");
		$(".absolute").prepend("<h3> Permanent Address: "+$paddr+"</h2><br>");
		$(".absolute").prepend("<h3> Address: "+$addr+"</h2><br>");
		$(".absolute").prepend("<h2> CNIC: "+$cnic+"</h2><br>");
	});
	$(".Close").click(function(){
		$(".absolute").addClass("hidden");
		$(".drawable").attr("src","data:image/gif;base64,R0lGODlhEAAQAPIAAP///wAAAMLCwkJCQgAAAGJiYoKCgpKSkiH/C05FVFNDQVBFMi4wAwEAAAAh/hpDcmVhdGVkIHdpdGggYWpheGxvYWQuaW5mbwAh+QQJCgAAACwAAAAAEAAQAAADMwi63P4wyklrE2MIOggZnAdOmGYJRbExwroUmcG2LmDEwnHQLVsYOd2mBzkYDAdKa+dIAAAh+QQJCgAAACwAAAAAEAAQAAADNAi63P5OjCEgG4QMu7DmikRxQlFUYDEZIGBMRVsaqHwctXXf7WEYB4Ag1xjihkMZsiUkKhIAIfkECQoAAAAsAAAAABAAEAAAAzYIujIjK8pByJDMlFYvBoVjHA70GU7xSUJhmKtwHPAKzLO9HMaoKwJZ7Rf8AYPDDzKpZBqfvwQAIfkECQoAAAAsAAAAABAAEAAAAzMIumIlK8oyhpHsnFZfhYumCYUhDAQxRIdhHBGqRoKw0R8DYlJd8z0fMDgsGo/IpHI5TAAAIfkECQoAAAAsAAAAABAAEAAAAzIIunInK0rnZBTwGPNMgQwmdsNgXGJUlIWEuR5oWUIpz8pAEAMe6TwfwyYsGo/IpFKSAAAh+QQJCgAAACwAAAAAEAAQAAADMwi6IMKQORfjdOe82p4wGccc4CEuQradylesojEMBgsUc2G7sDX3lQGBMLAJibufbSlKAAAh+QQJCgAAACwAAAAAEAAQAAADMgi63P7wCRHZnFVdmgHu2nFwlWCI3WGc3TSWhUFGxTAUkGCbtgENBMJAEJsxgMLWzpEAACH5BAkKAAAALAAAAAAQABAAAAMyCLrc/jDKSatlQtScKdceCAjDII7HcQ4EMTCpyrCuUBjCYRgHVtqlAiB1YhiCnlsRkAAAOwAAAAAAAAAAAA==");
		$(".absolute").find("h2,h3,br").remove();
	});
});
</script>
