        <div class='preloader'>
            <div class='loader-center'>
                <div class='loader'>
                    <div class="block">
			<div class="block-in">
			   <div class="clock2"></div>
			</div>
		    </div>
                </div>
            </div>
        </div>