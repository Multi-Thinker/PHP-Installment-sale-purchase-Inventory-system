  <script src="assets/js/jquery.min.js"></script>
        <!-- Include all compiled plugins (below), or include individual files as needed -->
        <script src="assets/js/bootstrap.min.js"></script>
        <script src="assets/plugins/owl-carousel/js/owl.carousel.min.js"></script>
        <script src="assets/plugins/megamenu/js/hover-dropdown-menu.js"></script>
        <script src="assets/plugins/megamenu/js/jquery.hover-dropdown-menu-addon.js"></script>
        <script src="assets/plugins/preloader/js/anime.min.js"></script>
        <script src="assets/js/main.js"></script>
         <script src='https://maps.googleapis.com/maps/api/js?v=3.exp&amp;key=AIzaSyDnJzryw5UTYs4q-8UN4FyTwWIHlxMSYXw'></script>