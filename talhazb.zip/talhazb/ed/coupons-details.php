<?php include "header.php"; ?>
        <div class="breadcrumb-section">
            <div class="breadcrumb-text">
                <div class="container">
                    <div class="row">
                        <div class="col-md-12 col-sm-12 col-xs-12">
                            <div class="breadcrumb-text padTB100">
                                <h3><span>coupon details</span></h3>
                                <ul class="breadcrumb-list">
                                    <li><a href="index-2.php">home</a></li>
                                    <li><a href="#">coupon details</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- //***Breadcrumb-Section End***// -->
        <!-- //***coupons-details Start***// -->
        <div class="deals bg padTB60">
            <div class="container">
                <div class="row">
                    <div class="col-md-9 col-sm-8 col-xs-12">
                        <div class="row">
                            <div class="col-md-12 col-sm-12 col-xs-12">
                                <div class="blog marB30">
                                    <div class="col-md-12 col-sm-12 col-xs-12">
                                        <div class="row">
                                            <figure>
                                                <img src="assets/img/all/coupon-detail.jpg" alt="">
                                            </figure>
                                        </div>
                                    </div>
                                </div>
                                <h4>About Awesome Vacation Spot</h4>
                                <p>Eu nunc porttitor class mollis tincidunt morbi aliquet praesent justo volutpat magna aliquam arcu volutpat ali
                                    quet dui cursus ad risus litora natoque amet faucibus massa nulla mollis praesent is nascetur cursus lobortis 
                                    nisl hac mollis fames arcu condimentum nibh accumsan pharetra mauris per arcu montes semper non justo 
                                    est pretium quisque
                                </p>
                                <h4 class="marT30">How Coupon Work ?</h4>
                                <p>Eu nunc porttitor class mollis tincidunt morbi aliquet praesent justo volutpat magna aliquam arcu volutpat ali
                                    quet dui cursus ad risus litora natoque amet faucibus massa nulla mollis praesent is nascetur cursus lobortis 
                                    nisl hac mollis fames arcu condimentum nibh accumsan pharetra mauris per arcu montes semper non justo 
                                    est pretium quisque
                                </p>
                                <div class="col-md-12 col-sm-12 col-xs-12 marT20">
                                    <div class="ask-btn">
                                        <div class="row">
                                            <a href="#" class="itg-btn cart-btn">ask question</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-12 col-sm-12 col-xs-12 marT30">
                                <div class="row">
                                    <div class="comments-form">
                                        <div class="coments col-md-12 col-sm-12 col-xs-12 marB30">
                                            <h3>add comments</h3>
                                        </div>
                                        <div class="col-md-6 col-sm-12 col-xs-12 marB30">
                                            <input type="text" name="name" value="" placeholder="Name">
                                        </div>
                                        <div class="col-md-6 col-sm-12 col-xs-12 marB30">
                                            <input type="text" name="email" value="" placeholder="Email">
                                        </div>
                                        <div class="col-md-12 col-sm-12 col-xs-12 marB30">
                                            <input type="text" name="subject" value="" placeholder="Subject">
                                        </div>
                                        <div class="col-md-12 col-sm-12 col-xs-12 marB30">
                                            <textarea placeholder="Message" rows="5"></textarea>
                                        </div>
                                        <div class="col-md-12 col-sm-12 col-xs-12">
                                            <button type="submit" class="itg-btn subcribes">subcribes now</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
					<div class="col-md-3 col-sm-4 col-xs-12">
                        <div class="row">
                            <div class="col-md-12 col-sm-12 col-xs-12">
                                <div class="search-bar">
                                    <div class="col-md-12 col-sm-12 col-xs-12">
                                        <div class="search_bar">
                                            <input type="text" name="search" placeholder="Search..">
                                            <button type="submit"><i class="fa fa-search" aria-hidden="true"></i></button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-12 col-sm-12 col-xs-12">
                                <div class="blog">
                                    <div id="blog" class="owl-carousel owlCarousel marT30">
                                        <div class="item">
                                            <div class="col-md-12 col-sm-12 col-xs-12">
                                                <div class="row">
                                                    <figure>
                                                        <img src="assets/img/blog/blog1.jpg" alt="">
                                                    </figure>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="item">
                                            <div class="col-md-12 col-sm-12 col-xs-12">
                                                <div class="row">
                                                    <figure>
                                                        <img src="assets/img/blog/blog-a.jpg" alt="">
                                                    </figure>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="item">
                                            <div class="col-md-12 col-sm-12 col-xs-12">
                                                <div class="row">
                                                    <figure>
                                                        <img src="assets/img/blog/blog-b.jpg" alt="">
                                                    </figure>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="blog-a">
                                    <p>Colorful Furnimart With High Up To 70% Discount On All Stores</p>
                                </div>
                            </div>
                            <div class="col-md-12 col-sm-12 col-xs-12">
                                <div class="latest-tweet marT20">
                                    <h4 class="red capital marB10"><a href="#">Latest tweets</a></h4>
                                    <h5 class="marB5"><i class="fa fa-twitter red" aria-hidden="true"></i> @Blackfriday.com</h5>
                                    <p>Lorem ipsum dolor sit acons tuadip iscing elit Fusce</p>
                                    <span class="red">www.itg.Com</span> 
                                    <p>4 hour ago</p>
                                    <h4 class="red capital marB10 marT30"><a href="#">Latest tweets</a></h4>
                                    <h5 class="marB5"><i class="fa fa-twitter red" aria-hidden="true"></i> @Blackfriday.com</h5>
                                    <p>Lorem ipsum dolor sit acons tuadip iscing elit Fusce</p>
                                    <span class="red">www.itg.Com</span> 
                                    <p>4 hour ago</p>
                                </div>
                            </div>
                            <div class="col-md-12 col-sm-12 col-xs-12">
                                <div class="trending-offers marT20">
                                    <h4 class="red capital marB10"><a href="#">Trending Offers</a></h4>
                                    <div class="trending">
                                        <div class="col-md-4 col-sm-4 col-xs-12">
                                            <div class="row">
                                                <figure>
                                                    <img src="assets/img/blog/blog2.jpg" alt="">
                                                </figure>
                                            </div>
                                        </div>
                                        <div class="col-md-8 col-sm-8 col-xs-12">
                                            <div class="row">
                                                <h5><a href="#">Flate 25% OFF on all Clothing</a></h5>
                                                <h5 class="red"><a href="#"><span>Read More</span></a></h5>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="trending">
                                        <div class="col-md-4 col-sm-4 col-xs-12">
                                            <div class="row">
                                                <figure>
                                                    <img src="assets/img/blog/blog3.jpg" alt="">
                                                </figure>
                                            </div>
                                        </div>
                                        <div class="col-md-8 col-sm-8 col-xs-12">
                                            <div class="row">
                                                <h5><a href="#">Flate 25% OFF on all Clothing</a></h5>
                                                <h5 class="red"><a href="#"><span>Read More</span></a></h5>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="trending">
                                        <div class="col-md-4 col-sm-4 col-xs-12">
                                            <div class="row">
                                                <figure>
                                                    <img src="assets/img/blog/blog4.jpg" alt="">
                                                </figure>
                                            </div>
                                        </div>
                                        <div class="col-md-8 col-sm-8 col-xs-12">
                                            <div class="row">
                                                <h5><a href="#">Flate 25% OFF on all Clothing</a></h5>
                                                <h5 class="red"><a href="#"><span>Read More</span></a></h5>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="trending">
                                        <div class="col-md-4 col-sm-4 col-xs-12">
                                            <div class="row">
                                                <figure>
                                                    <img src="assets/img/blog/blog5.jpg" alt="">
                                                </figure>
                                            </div>
                                        </div>
                                        <div class="col-md-8 col-sm-8 col-xs-12">
                                            <div class="row">
                                                <h5><a href="#">Flate 25% OFF on all Clothing</a></h5>
                                                <h5 class="red"><a href="#"><span>Read More</span></a></h5>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-12 col-sm-12 col-xs-12">
                                <div class="tags marT20">
                                    <h4 class="orange marB10 capital"><a href="#">Popular Tags</a></h4>
                                    <ul>
                                        <li><a href="#">art</a></li>
                                        <li><a href="#">paint</a></li>
                                        <li><a href="#">floor</a></li>
                                        <li><a href="#">exterior</a></li>
                                        <li><a href="#">interrior</a></li>
                                        <li><a href="#">paint</a></li>
                                        <li><a href="#">floor</a></li>
                                        <li><a href="#">industry</a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- //***coupons-details End***// -->
        <div class="clear"></div>
        <?php include "footer.php" ?>
    </body>

<!-- Mirrored from preview.yrthemes.com/thanks-giving/coupons-details.php by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 22 Dec 2017 14:59:24 GMT -->
</html>