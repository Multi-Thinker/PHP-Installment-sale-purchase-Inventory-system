     <div class="main-footer padT60">
            <div class="container-fluid">
                <div class="col-md-4 col-sm-4 col-xs-12">
                    <div class="footer-logo">
                        <a href="#"><img src="assets/img/footer-logo.svg"  width="300px" alt=""></a>
                        <p>Lorem Ipsum is simply dummy text 
                            of the printing and typesetting industry. 
                            Lorem Ipsum has been the industry's the 
                            standard dummy 
                        </p>
                        <img src="assets/img/all/payment-icon.png" alt="">
                    </div>
                </div>
                <div class="col-md-2 col-sm-2 col-xs-12">
                    <h4>information</h4>
                    <p><a href="#">about Us</a></p>
                    <p><a href="#">service</a></p>
                    <p><a href="#">recent</a></p>
                    <p><a href="#">seller</a></p>
                    <p><a href="#">privacy</a></p>
                    <p><a href="#">policy</a></p>
                </div>
                <div class="col-md-2 col-sm-2 col-xs-12">
                    <h4>brands</h4>
                    <p><a href="#">adidas</a></p>
                    <p><a href="#">ghd</a></p>
                    <p><a href="#">aero</a></p>
                    <p><a href="#">holster</a></p>
                    <p><a href="#">nike</a></p>
                    <p><a href="#">urban</a></p>
                    <p><a href="#">lovehoney</a></p>
                </div>
                <div class="col-md-2 col-sm-2 col-xs-12">
                    <h4>categorie</h4>
                    <p><a href="#">fashion</a></p>
                    <p><a href="#">accesories</a></p>
                    <p><a href="#">home & garden</a></p>
                    <p><a href="#">furnimart</a></p>
                    <p><a href="#">electronics</a></p>
                    <p><a href="#">foods</a></p>
                </div>
                <div class="col-md-2 col-sm-2 col-xs-12">
                    <h4>my account</h4>
                    <p><a href="#">sign in</a></p>
                    <p><a href="#">view cart</a></p>
                    <p><a href="#">my wishlist</a></p>
                    <p><a href="#">track order</a></p>
                    <p><a href="#">shipping policy</a></p>
                    <p><a href="#">help</a></p>
                </div>
            </div>
        </div>
        <div class="copyright-section">
            <div class="col-md-12 col-sm-12 col-xs-12">
                <p><i class="fa fa-copyright" aria-hidden="true"></i> 2017 <a href="#"><span class="itg-color"> EdPerks</span></a></p>
            </div>
        </div>
        <?php include "script.php"; ?>