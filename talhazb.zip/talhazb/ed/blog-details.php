<?php include "header.php"; ?>
        <div class="breadcrumb-section">
            <div class="breadcrumb-text">
                <div class="container">
                    <div class="row">
                        <div class="col-md-12 col-sm-12 col-xs-12">
                            <div class="breadcrumb-text padTB100">
                                <h3><span>blog</span></h3>
                                <ul class="breadcrumb-list">
                                    <li><a href="index-2.php">home</a></li>
                                    <li><a href="#">blog details</a></li>
                                    <li><a href="#">sidebar</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- //***breadcrumb-section End***// -->
        <!-- //***Blog-List-Sidebar Start***// -->
        <div class="latest-blog bg padTB60">
            <div class="container">
                <div class="row">
                    <div class="col-md-9 col-sm-8 col-xs-12">
                        <div class="row">
                            <div class="col-md-12 col-sm-12 col-xs-12">
                                <div class="col-md-12 col-sm-12 col-xs-12">
                                    <div class="row">
                                        <figure>
                                            <img src="assets/img/blog/blog.jpg" alt="">
                                        </figure>
                                        <div class="col-md-12">
                                            <div class="row">
                                                <div class="blog-details">
                                                    <h4 class="hover capital marB10">post title here</h4>
                                                    <ul class="marB10 fonts">
                                                        <li class="hover"><a href="#"><i class="fa fa-calendar-o" aria-hidden="true"></i> MAY 24, 2015</a></li>
                                                        <li class="marL10 upper hover"><a href="#"><i class="fa fa-comment" aria-hidden="true"></i> comments</a></li>
                                                    </ul>
                                                    <p>Lorem Ipsum is simply dummy text of therinting andey type setting industry lorem Ipsum is simply dummy.</p>
                                                    <p>Towards Examined Wherever Less Eel Much Ahead ipsum dolor sit Lorem Ipsum is simply dummy text of printing Lorem Ipsum is simply dummy text of the printing Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
                                                    <p>Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam,</p>
                                                    <p>Eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor amet, consectetur, adipisci velit, sed quia non numquam</p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-12 col-sm-12 col-xs-12">
                                    <div class="row">
                                        <div class="author marT30">
                                            <p>Aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla par Excepteur sin occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum totam rem aperiam.</p>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-12 col-sm-12 col-xs-12">
                                    <div class="row">
                                        <div class="share-this marT30">
                                            <h3 class="capital">share this</h3>
                                            <ul class="marT20 marB30">
                                                <li><a href="#"><i class="fa fa-share-alt" aria-hidden="true"></i></a></li>
                                                <li><a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
                                                <li><a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
                                                <li><a href="#"><i class="fa fa-google-plus" aria-hidden="true"></i></a></li>
                                                <li><a href="#"><i class="fa fa-linkedin" aria-hidden="true"></i></a></li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-12 col-sm-12 col-xs-12">
                                    <div class="comments-area">
                                        <div class="row">
                                            <h3 class="capital marT30 marB40">comments found</h3>
                                            <div class="col-md-2 col-sm-2">
                                                <figure>
                                                    <img src="assets/img/all/comment1.jpg" alt class="img-circle">
                                                </figure>
                                            </div>
                                            <div class="col-md-10 col-sm-10 marB30">
                                                <a href="#"><span class="red">jon doe</span></a><a href="#"> 4 Nov-2017</a>
                                                <p>Lorem Ipsum is simply dummy text of the printing and etting industry orem Ipsum has been the industry's standard my text ever since they 1500s. the printing and etting dustry orem Ipsum has been the standard my text ever the since they 1500s.</p>
                                                <a href="#" class="red"><span><i class="fa fa-reply" aria-hidden="true"></i> reply</span></a>
                                            </div>
                                            <div class="depth padL50">
                                                <div class="col-md-2 col-sm-2">
                                                    <figure>
                                                        <img src="assets/img/all/comment2.jpg" alt class="img-circle">
                                                    </figure>
                                                </div>
                                                <div class="col-md-10 col-sm-10 marB30">
                                                    <a href="#"><span class="red">jon doe</span></a><a href="#"> 4 Nov-2017</a>
                                                    <p>Lorem Ipsum is simply dummy text of the printing and etting industry orem Ipsum has been the industry's standard my text ever since they 1500s. the printing and etting dustry orem Ipsum has been the standard my text ever the since they 1500s.</p>
                                                    <a href="#" class="red"><span><i class="fa fa-reply" aria-hidden="true"></i> reply</span></a>
                                                </div>
                                            </div>
                                            <div class="col-md-2 col-sm-2">
                                                <figure>
                                                    <img src="assets/img/all/comment3.jpg" alt class="img-circle">
                                                </figure>
                                            </div>
                                            <div class="col-md-10 col-sm-10 marB30">
                                                <a href="#"><span class="red">jon doe</span></a><a href="#"> 4 Nov-2017</a>
                                                <p>Lorem Ipsum is simply dummy text of the printing and etting industry orem Ipsum has been the industry's standard my text ever since they 1500s. the printing and etting dustry orem Ipsum has been the standard my text ever the since they 1500s.</p>
                                                <a href="#" class="red"><span><i class="fa fa-reply" aria-hidden="true"></i> reply</span></a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-12 col-sm-12 col-xs-12 marT30">
                                    <div class="row">
                                        <div class="comments-form">
                                            <div class="coments col-md-12 col-sm-12 col-xs-12 marB30">
                                                <h3>add comments</h3>
                                            </div>
                                            <div class="col-md-6 col-sm-6 col-xs-12 marB30">
                                                <input type="text" name="name" value="" placeholder="Name">
                                            </div>
                                            <div class="col-md-6 col-sm-6 col-xs-12 marB30">
                                                <input type="text" name="email" value="" placeholder="Email">
                                            </div>
                                            <div class="col-md-6 col-sm-6 col-xs-12 marB30">
                                                <input type="text" name="Number" value="" placeholder="Number">
                                            </div>
                                            <div class="col-md-6 col-sm-6 col-xs-12 marB30">
                                                <input type="text" name="Website Url" value="" placeholder="Website Url">
                                            </div>
                                            <div class="col-md-12 col-sm-12 col-xs-12 marB30">
                                                <textarea placeholder="Message" rows="5"></textarea>
                                            </div>
                                            <div class="col-md-12 col-sm-12 col-xs-12">
                                                <button type="submit" class="itg-btn subcribes">subcribes now</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
					<div class="col-md-3 col-sm-4 col-xs-12">
                        <div class="row">
                            <div class="col-md-12 col-sm-12 col-xs-12">
                                <div class="search-bar">
                                    <div class="col-md-12 col-sm-12 col-xs-12">
                                        <div class="search_bar">
                                            <input type="text" name="search" placeholder="Search..">
                                            <button type="submit"><i class="fa fa-search" aria-hidden="true"></i></button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-12 col-sm-12 col-xs-12">
                                <div class="blog">
                                    <div id="blog" class="owl-carousel owlCarousel marT30">
                                        <div class="item">
                                            <div class="col-md-12 col-sm-12 col-xs-12">
                                                <div class="row">
                                                    <figure>
                                                        <img src="assets/img/blog/blog1.jpg" alt="">
                                                    </figure>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="item">
                                            <div class="col-md-12 col-sm-12 col-xs-12">
                                                <div class="row">
                                                    <figure>
                                                        <img src="assets/img/blog/blog-a.jpg" alt="">
                                                    </figure>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="item">
                                            <div class="col-md-12 col-sm-12 col-xs-12">
                                                <div class="row">
                                                    <figure>
                                                        <img src="assets/img/blog/blog-b.jpg" alt="">
                                                    </figure>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="blog-a">
                                    <p>Colorful Furnimart With High Up To 70% Discount On All Stores</p>
                                </div>
                            </div>
                            <div class="col-md-12 col-sm-12 col-xs-12">
                                <div class="latest-tweet marT20">
                                    <h4 class="red capital marB10"><a href="#">Latest tweets</a></h4>
                                    <h5 class="marB5"><i class="fa fa-twitter red" aria-hidden="true"></i> @Blackfriday.com</h5>
                                    <p>Lorem ipsum dolor sit acons tuadip iscing elit Fusce</p>
                                    <span class="red">www.itg.Com</span> 
                                    <p>4 hour ago</p>
                                    <h4 class="red capital marB10 marT30"><a href="#">Latest tweets</a></h4>
                                    <h5 class="marB5"><i class="fa fa-twitter red" aria-hidden="true"></i> @Blackfriday.com</h5>
                                    <p>Lorem ipsum dolor sit acons tuadip iscing elit Fusce</p>
                                    <span class="red">www.itg.Com</span> 
                                    <p>4 hour ago</p>
                                </div>
                            </div>
                            <div class="col-md-12 col-sm-12 col-xs-12">
                                <div class="trending-offers marT20">
                                    <h4 class="red capital marB10"><a href="#">Trending Offers</a></h4>
                                    <div class="trending">
                                        <div class="col-md-4 col-sm-4 col-xs-12">
                                            <div class="row">
                                                <figure>
                                                    <img src="assets/img/blog/blog2.jpg" alt="">
                                                </figure>
                                            </div>
                                        </div>
                                        <div class="col-md-8 col-sm-8 col-xs-12">
                                            <div class="row">
                                                <h5><a href="#">Flate 25% OFF on all Clothing</a></h5>
                                                <h5 class="red"><a href="#"><span>Read More</span></a></h5>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="trending">
                                        <div class="col-md-4 col-sm-4 col-xs-12">
                                            <div class="row">
                                                <figure>
                                                    <img src="assets/img/blog/blog3.jpg" alt="">
                                                </figure>
                                            </div>
                                        </div>
                                        <div class="col-md-8 col-sm-8 col-xs-12">
                                            <div class="row">
                                                <h5><a href="#">Flate 25% OFF on all Clothing</a></h5>
                                                <h5 class="red"><a href="#"><span>Read More</span></a></h5>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="trending">
                                        <div class="col-md-4 col-sm-4 col-xs-12">
                                            <div class="row">
                                                <figure>
                                                    <img src="assets/img/blog/blog4.jpg" alt="">
                                                </figure>
                                            </div>
                                        </div>
                                        <div class="col-md-8 col-sm-8 col-xs-12">
                                            <div class="row">
                                                <h5><a href="#">Flate 25% OFF on all Clothing</a></h5>
                                                <h5 class="red"><a href="#"><span>Read More</span></a></h5>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="trending">
                                        <div class="col-md-4 col-sm-4 col-xs-12">
                                            <div class="row">
                                                <figure>
                                                    <img src="assets/img/blog/blog5.jpg" alt="">
                                                </figure>
                                            </div>
                                        </div>
                                        <div class="col-md-8 col-sm-8 col-xs-12">
                                            <div class="row">
                                                <h5><a href="#">Flate 25% OFF on all Clothing</a></h5>
                                                <h5 class="red"><a href="#"><span>Read More</span></a></h5>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-12 col-sm-12 col-xs-12">
                                <div class="tags marT20">
                                    <h4 class="red marB10 capital"><a href="#">Popular Tags</a></h4>
                                    <ul>
                                        <li><a href="#">art</a></li>
                                        <li><a href="#">paint</a></li>
                                        <li><a href="#">floor</a></li>
                                        <li><a href="#">exterior</a></li>
                                        <li><a href="#">interrior</a></li>
                                        <li><a href="#">paint</a></li>
                                        <li><a href="#">floor</a></li>
                                        <li><a href="#">industry</a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- //***Blog-List-Sidebar End***// -->
        <div class="clear"></div>
        <?php include "footer.php" ?>
    </body>

</html>