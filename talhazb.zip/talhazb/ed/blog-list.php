<?php include "header.php"; ?>
        <div class="breadcrumb-section">
            <div class="breadcrumb-text">
                <div class="container">
                    <div class="row">
                        <div class="col-md-12 col-sm-12 col-xs-12">
                            <div class="breadcrumb-text padTB100">
                                <h3><span>blog</span></h3>
                                <ul class="breadcrumb-list">
                                    <li><a href="index-2.php">home</a></li>
                                    <li><a href="#">blog list</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- //***breadcrumb-section End***// -->
        <!-- //***Blog-List Start***// -->
        <div class="latest-blog bg slidernav padTB60">
            <div class="container">
                <div class="row">
                    <div class="col-md-12 col-sm-12 col-xs-12 marB30">
                        <div class="box-x">
                            <div class="col-md-4 col-sm-5 col-xs-12">
                                <div class="row">
                                    <figure>
                                        <img src="assets/img/all/imagef.jpg" alt="">
                                    </figure>
                                </div>
                            </div>
                            <div class="col-md-8 col-sm-7 col-xs-12">
                                <div class="row">
                                    <div class="box-detail">
                                        <div class="col-md-12">
                                            <div class="row">
                                                <h4 class="hover marB10"><a href="blog-details.php">post title here</a></h4>
                                                <ul class="marB10 fonts">
                                                    <li><a href="#"><i class="fa fa-calendar-o" aria-hidden="true"></i> MAY 24, 2015</a></li>
                                                    <li class="marL10 upper"><a href="#"><i class="fa fa-comment" aria-hidden="true"></i> comments</a></li>
                                                </ul>
                                                <p>Lorem Ipsum is simply dummy text of the rinting andey type setting industry lorem Ipsum is simply dummy type setting industry lorem Ipsum.</p>
                                                <span><a href="blog-details.php" class="hover">read more</a></span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-12 col-sm-12 col-xs-12 marB30">
                        <div class="box-x">
                            <div class="col-md-4 col-sm-5 col-xs-12">
                                <div class="row">
                                    <figure>
                                        <img src="assets/img/all/imageg.jpg" alt="">
                                    </figure>
                                </div>
                            </div>
                            <div class="col-md-8 col-sm-7 col-xs-12">
                                <div class="row">
                                    <div class="box-detail">
                                        <div class="col-md-12">
                                            <div class="row">
                                                <h4 class="hover marB10"><a href="blog-details.php">post title here</a></h4>
                                                <ul class="marB10 fonts">
                                                    <li><a href="#"><i class="fa fa-calendar-o" aria-hidden="true"></i> MAY 24, 2015</a></li>
                                                    <li class="marL10 upper"><a href="#"><i class="fa fa-comment" aria-hidden="true"></i> comments</a></li>
                                                </ul>
                                                <p>Lorem Ipsum is simply dummy text of the rinting andey type setting industry lorem Ipsum is simply dummy type setting industry lorem Ipsum.</p>
                                                <span><a href="blog-details.php" class="hover">read more</a></span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-12 col-sm-12 col-xs-12 marB30">
                        <div class="box-x">
                            <div class="col-md-4 col-sm-5 col-xs-12">
                                <div class="row">
                                    <figure>
                                        <img src="assets/img/all/imageh.jpg" alt="">
                                    </figure>
                                </div>
                            </div>
                            <div class="col-md-8 col-sm-7 col-xs-12">
                                <div class="row">
                                    <div class="box-detail">
                                        <div class="col-md-12">
                                            <div class="row">
                                                <h4 class="hover marB10"><a href="blog-details.php">post title here</a></h4>
                                                <ul class="marB10 fonts">
                                                    <li><a href="#"><i class="fa fa-calendar-o" aria-hidden="true"></i> MAY 24, 2015</a></li>
                                                    <li class="marL10 upper"><a href="#"><i class="fa fa-comment" aria-hidden="true"></i> comments</a></li>
                                                </ul>
                                                <p>Lorem Ipsum is simply dummy text of the rinting andey type setting industry lorem Ipsum is simply dummy type setting industry lorem Ipsum.</p>
                                                <span><a href="blog-details.php" class="hover">read more</a></span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-12 col-sm-12 col-xs-12 marB30">
                        <div class="box-x">
                            <div class="col-md-4 col-sm-5 col-xs-12">
                                <div class="row">
                                    <figure>
                                        <img src="assets/img/all/imagei.jpg" alt="">
                                    </figure>
                                </div>
                            </div>
                            <div class="col-md-8 col-sm-7 col-xs-12">
                                <div class="row">
                                    <div class="box-detail">
                                        <div class="col-md-12">
                                            <div class="row">
                                                <h4 class="hover marB10"><a href="blog-details.php">post title here</a></h4>
                                                <ul class="marB10 fonts">
                                                    <li><a href="#"><i class="fa fa-calendar-o" aria-hidden="true"></i> MAY 24, 2015</a></li>
                                                    <li class="marL10 upper"><a href="#"><i class="fa fa-comment" aria-hidden="true"></i> comments</a></li>
                                                </ul>
                                                <p>Lorem Ipsum is simply dummy text of the rinting andey type setting industry lorem Ipsum is simply dummy type setting industry lorem Ipsum.</p>
                                                <span><a href="blog-details.php" class="hover">read more</a></span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-12 col-sm-12 col-xs-12 marB30">
                        <div class="box-x">
                            <div class="col-md-4 col-sm-5 col-xs-12">
                                <div class="row">
                                    <figure>
                                        <img src="assets/img/all/imagej.jpg" alt="">
                                    </figure>
                                </div>
                            </div>
                            <div class="col-md-8 col-sm-7 col-xs-12">
                                <div class="row">
                                    <div class="box-detail">
                                        <div class="col-md-12">
                                            <div class="row">
                                                <h4 class="hover marB10"><a href="blog-details.php">post title here</a></h4>
                                                <ul class="marB10 fonts">
                                                    <li><a href="#"><i class="fa fa-calendar-o" aria-hidden="true"></i> MAY 24, 2015</a></li>
                                                    <li class="marL10 upper"><a href="#"><i class="fa fa-comment" aria-hidden="true"></i> comments</a></li>
                                                </ul>
                                                <p>Lorem Ipsum is simply dummy text of the rinting andey type setting industry lorem Ipsum is simply dummy type setting industry lorem Ipsum.</p>
                                                <span><a href="blog-details.php" class="hover">read more</a></span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-12 col-sm-12 col-xs-12">
                        <div class="pagination-box text-center">
                            <a href="#"><span><i class="fa fa-angle-left" aria-hidden="true"></i></span></a>
                            <a href="#"><span class="active-red">1</span></a>
                            <a href="#"><span>2</span></a>
                            <a href="#"><span>3</span></a>
                            <a href="#"><span>4</span></a>
                            <a href="#"><span>5</span></a>
                            <a href="#"><span><i class="fa fa-angle-right" aria-hidden="true"></i></span></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- //***Blog-List End***// -->
        <div class="clear"></div>
       <?php include "footer.php" ?>
    </body>

<!-- Mirrored from preview.yrthemes.com/thanks-giving/blog-list.php by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 22 Dec 2017 15:01:23 GMT -->
</html>