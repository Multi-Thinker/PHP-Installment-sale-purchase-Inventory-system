<?php include "header.php"; ?>
        <div class="breadcrumb-section">
            <div class="breadcrumb-text">
                <div class="container">
                    <div class="row">
                        <div class="col-md-12 col-sm-12 col-xs-12">
                            <div class="breadcrumb-text padTB100">
                                <h3><span>deals</span></h3>
                                <ul class="breadcrumb-list">
                                    <li><a href="index-2.php">home</a></li>
                                    <li><a href="#">deals list</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- //***Breadcrumb-Section End***// -->
        <!-- //***Deals-list Start***// -->
        <div class="deals bg padTB60">
            <div class="container">
                <div class="row">
                    <div class="deals marB30">
                        <div class="col-md-4 col-sm-5 col-xs-12 padR0 box-r">
                            <figure>
                                <img src="assets/img/all/image1.jpg" alt="">
                            </figure>
                        </div>
                        <div class="col-md-8 col-sm-7 col-xs-12 padL0 box-l">
                            <div class="box-detail description">
                                <div class="col-md-10 col-sm-9 col-xs-8 sm-b">
                                    <div class="row">
                                        <h4 class="hover marB20"><a href="deals-single.php">title goes here</a></h4>
                                        <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem  Ipsum has been the industry's standard dummy text ever since</p>
                                        <h4 class="marT20"><span class="red"><i class="fa fa-usd" aria-hidden="true"></i>190</span>  <del><span class="grey"><i class="fa fa-usd" aria-hidden="true"></i>250</span></del></h4>
                                    </div>
                                </div>
                                <div class="col-md-2 col-sm-3 col-xs-4 text-right">
                                    <div class="row">
                                        <ul class="stars">
                                            <li><i class="fa fa-star"></i></li>
                                            <li><i class="fa fa-star"></i></li>
                                            <li><i class="fa fa-star"></i></li>
                                            <li><i class="fa fa-star"></i></li>
                                            <li class="grey-a"><i class="fa fa-star"></i></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                            <div class="border"></div>
                            <div class="box-detail description bg-b">
                                <div class="col-md-10 col-sm-10 col-xs-12">
                                    <div class="row">
                                        <div class="demo1" data-expiry="mar 20, 2018 15:37:25">
                                            <div class="col-md-3 col-sm-3 col-xs-3">
                                                <div class="timer">000<span>d.</span></div>
                                            </div>
                                            <div class="col-md-3 col-sm-3 col-xs-3">
                                                <div class="timer">00<span>h.</span></div>
                                            </div>
                                            <div class="col-md-3 col-sm-3 col-xs-3">
                                                <div class="timer">00<span>m.</span></div>
                                            </div>
                                            <div class="col-md-3 col-sm-3 col-xs-3">
                                                <div class="timer">00<span>s.</span></div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-2 col-sm-2 col-xs-12">
                                    <div class="row">
                                        <div class="cart-icon">
                                            <a href="#"><i class="fa fa-shopping-cart" aria-hidden="true"></i></a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="deals marB30">
                        <div class="col-md-4 col-sm-5 col-xs-12 padR0 box-r">
                            <figure>
                                <img src="assets/img/all/image2.jpg" alt="">
                            </figure>
                        </div>
                        <div class="col-md-8 col-sm-7 col-xs-12 padL0 box-l">
                            <div class="box-detail description">
                                <div class="col-md-10 col-sm-9 col-xs-8 sm-b">
                                    <div class="row">
                                        <h4 class="hover marB20"><a href="deals-single.php">title goes here</a></h4>
                                        <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem  Ipsum has been the industry's standard dummy text ever since</p>
                                        <h4 class="marT20"><span class="red"><i class="fa fa-usd" aria-hidden="true"></i>190</span>  <del><span class="grey"><i class="fa fa-usd" aria-hidden="true"></i>250</span></del></h4>
                                    </div>
                                </div>
                                <div class="col-md-2 col-sm-3 col-xs-4 text-right">
                                    <div class="row">
                                        <ul class="stars">
                                            <li><i class="fa fa-star"></i></li>
                                            <li><i class="fa fa-star"></i></li>
                                            <li><i class="fa fa-star"></i></li>
                                            <li><i class="fa fa-star"></i></li>
                                            <li class="grey-a"><i class="fa fa-star"></i></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                            <div class="border"></div>
                            <div class="box-detail description bg-b">
                                <div class="col-md-10 col-sm-10 col-xs-12">
                                    <div class="row">
                                        <div class="demo1" data-expiry="mar 10, 2018 15:37:25">
                                            <div class="col-md-3 col-sm-3 col-xs-3">
                                                <div class="timer">000<span>d.</span></div>
                                            </div>
                                            <div class="col-md-3 col-sm-3 col-xs-3">
                                                <div class="timer">00<span>h.</span></div>
                                            </div>
                                            <div class="col-md-3 col-sm-3 col-xs-3">
                                                <div class="timer">00<span>m.</span></div>
                                            </div>
                                            <div class="col-md-3 col-sm-3 col-xs-3">
                                                <div class="timer">00<span>s.</span></div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-2 col-sm-2 col-xs-12">
                                    <div class="row">
                                        <div class="cart-icon">
                                            <a href="#"><i class="fa fa-shopping-cart" aria-hidden="true"></i></a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="deals marB30">
                        <div class="col-md-4 col-sm-5 col-xs-12 padR0 box-r">
                            <figure>
                                <img src="assets/img/all/image3.jpg" alt="">
                            </figure>
                        </div>
                        <div class="col-md-8 col-sm-7 col-xs-12 padL0 box-l">
                            <div class="box-detail description">
                                <div class="col-md-10 col-sm-9 col-xs-8 sm-b">
                                    <div class="row">
                                        <h4 class="hover marB20"><a href="deals-single.php">title goes here</a></h4>
                                        <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem  Ipsum has been the industry's standard dummy text ever since</p>
                                        <h4 class="marT20"><span class="red"><i class="fa fa-usd" aria-hidden="true"></i>190</span>  <del><span class="grey"><i class="fa fa-usd" aria-hidden="true"></i>250</span></del></h4>
                                    </div>
                                </div>
                                <div class="col-md-2 col-sm-3 col-xs-4 text-right">
                                    <div class="row">
                                        <ul class="stars">
                                            <li><i class="fa fa-star"></i></li>
                                            <li><i class="fa fa-star"></i></li>
                                            <li><i class="fa fa-star"></i></li>
                                            <li><i class="fa fa-star"></i></li>
                                            <li class="grey-a"><i class="fa fa-star"></i></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                            <div class="border"></div>
                            <div class="box-detail description bg-b">
                                <div class="col-md-10 col-sm-10 col-xs-12">
                                    <div class="row">
                                        <div class="demo1" data-expiry="jan 20, 2018 15:37:25">
                                            <div class="col-md-3 col-sm-3 col-xs-3">
                                                <div class="timer">000<span>d.</span></div>
                                            </div>
                                            <div class="col-md-3 col-sm-3 col-xs-3">
                                                <div class="timer">00<span>h.</span></div>
                                            </div>
                                            <div class="col-md-3 col-sm-3 col-xs-3">
                                                <div class="timer">00<span>m.</span></div>
                                            </div>
                                            <div class="col-md-3 col-sm-3 col-xs-3">
                                                <div class="timer">00<span>s.</span></div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-2 col-sm-2 col-xs-12">
                                    <div class="row">
                                        <div class="cart-icon">
                                            <a href="#"><i class="fa fa-shopping-cart" aria-hidden="true"></i></a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="deals marB30">
                        <div class="col-md-4 col-sm-5 col-xs-12 padR0 box-r">
                            <figure>
                                <img src="assets/img/all/image4.jpg" alt="">
                            </figure>
                        </div>
                        <div class="col-md-8 col-sm-7 col-xs-12 padL0 box-l">
                            <div class="box-detail description">
                                <div class="col-md-10 col-sm-9 col-xs-8 sm-b">
                                    <div class="row">
                                        <h4 class="hover marB20"><a href="deals-single.php">title goes here</a></h4>
                                        <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem  Ipsum has been the industry's standard dummy text ever since</p>
                                        <h4 class="marT20"><span class="red"><i class="fa fa-usd" aria-hidden="true"></i>190</span>  <del><span class="grey"><i class="fa fa-usd" aria-hidden="true"></i>250</span></del></h4>
                                    </div>
                                </div>
                                <div class="col-md-2 col-sm-3 col-xs-4 text-right">
                                    <div class="row">
                                        <ul class="stars">
                                            <li><i class="fa fa-star"></i></li>
                                            <li><i class="fa fa-star"></i></li>
                                            <li><i class="fa fa-star"></i></li>
                                            <li><i class="fa fa-star"></i></li>
                                            <li class="grey-a"><i class="fa fa-star"></i></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                            <div class="border"></div>
                            <div class="box-detail description bg-b">
                                <div class="col-md-10 col-sm-10 col-xs-12">
                                    <div class="row">
                                        <div class="demo1" data-expiry="feb 5, 2018 15:37:25">
                                            <div class="col-md-3 col-sm-3 col-xs-3">
                                                <div class="timer">000<span>d.</span></div>
                                            </div>
                                            <div class="col-md-3 col-sm-3 col-xs-3">
                                                <div class="timer">00<span>h.</span></div>
                                            </div>
                                            <div class="col-md-3 col-sm-3 col-xs-3">
                                                <div class="timer">00<span>m.</span></div>
                                            </div>
                                            <div class="col-md-3 col-sm-3 col-xs-3">
                                                <div class="timer">00<span>s.</span></div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-2 col-sm-2 col-xs-12">
                                    <div class="row">
                                        <div class="cart-icon">
                                            <a href="#"><i class="fa fa-shopping-cart" aria-hidden="true"></i></a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="deals marB30">
                        <div class="col-md-4 col-sm-5 col-xs-12 padR0 box-r">
                            <figure>
                                <img src="assets/img/all/image5.jpg" alt="">
                            </figure>
                        </div>
                        <div class="col-md-8 col-sm-7 col-xs-12 padL0 box-l">
                            <div class="box-detail description">
                                <div class="col-md-10 col-sm-9 col-xs-8 sm-b">
                                    <div class="row">
                                        <h4 class="hover marB20"><a href="deals-single.php">title goes here</a></h4>
                                        <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem  Ipsum has been the industry's standard dummy text ever since</p>
                                        <h4 class="marT20"><span class="red"><i class="fa fa-usd" aria-hidden="true"></i>190</span>  <del><span class="grey"><i class="fa fa-usd" aria-hidden="true"></i>250</span></del></h4>
                                    </div>
                                </div>
                                <div class="col-md-2 col-sm-3 col-xs-4 text-right">
                                    <div class="row">
                                        <ul class="stars">
                                            <li><i class="fa fa-star"></i></li>
                                            <li><i class="fa fa-star"></i></li>
                                            <li><i class="fa fa-star"></i></li>
                                            <li><i class="fa fa-star"></i></li>
                                            <li class="grey-a"><i class="fa fa-star"></i></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                            <div class="border"></div>
                            <div class="box-detail description bg-b">
                                <div class="col-md-10 col-sm-10 col-xs-12">
                                    <div class="row">
                                        <div class="demo1" data-expiry="april 2, 2018 15:37:25">
                                            <div class="col-md-3 col-sm-3 col-xs-3">
                                                <div class="timer">000<span>d.</span></div>
                                            </div>
                                            <div class="col-md-3 col-sm-3 col-xs-3">
                                                <div class="timer">00<span>h.</span></div>
                                            </div>
                                            <div class="col-md-3 col-sm-3 col-xs-3">
                                                <div class="timer">00<span>m.</span></div>
                                            </div>
                                            <div class="col-md-3 col-sm-3 col-xs-3">
                                                <div class="timer">00<span>s.</span></div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-2 col-sm-2 col-xs-12">
                                    <div class="row">
                                        <div class="cart-icon">
                                            <a href="#"><i class="fa fa-shopping-cart" aria-hidden="true"></i></a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="deals marB30">
                        <div class="col-md-4 col-sm-5 col-xs-12 padR0 box-r">
                            <figure>
                                <img src="assets/img/all/image6.jpg" alt="">
                            </figure>
                        </div>
                        <div class="col-md-8 col-sm-7 col-xs-12 padL0 box-l">
                            <div class="box-detail description">
                                <div class="col-md-10 col-sm-9 col-xs-8 sm-b">
                                    <div class="row">
                                        <h4 class="hover marB20"><a href="deals-single.php">title goes here</a></h4>
                                        <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem  Ipsum has been the industry's standard dummy text ever since</p>
                                        <h4 class="marT20"><span class="red"><i class="fa fa-usd" aria-hidden="true"></i>190</span>  <del><span class="grey"><i class="fa fa-usd" aria-hidden="true"></i>250</span></del></h4>
                                    </div>
                                </div>
                                <div class="col-md-2 col-sm-3 col-xs-4 text-right">
                                    <div class="row">
                                        <ul class="stars">
                                            <li><i class="fa fa-star"></i></li>
                                            <li><i class="fa fa-star"></i></li>
                                            <li><i class="fa fa-star"></i></li>
                                            <li><i class="fa fa-star"></i></li>
                                            <li class="grey-a"><i class="fa fa-star"></i></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                            <div class="border"></div>
                            <div class="box-detail description bg-b">
                                <div class="col-md-10 col-sm-10 col-xs-12">
                                    <div class="row">
                                        <div class="demo1" data-expiry="mar 2, 2018 15:37:25">
                                            <div class="col-md-3 col-sm-3 col-xs-3">
                                                <div class="timer">000<span>d.</span></div>
                                            </div>
                                            <div class="col-md-3 col-sm-3 col-xs-3">
                                                <div class="timer">00<span>h.</span></div>
                                            </div>
                                            <div class="col-md-3 col-sm-3 col-xs-3">
                                                <div class="timer">00<span>m.</span></div>
                                            </div>
                                            <div class="col-md-3 col-sm-3 col-xs-3">
                                                <div class="timer">00<span>s.</span></div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-2 col-sm-2 col-xs-12">
                                    <div class="row">
                                        <div class="cart-icon">
                                            <a href="#"><i class="fa fa-shopping-cart" aria-hidden="true"></i></a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-12 col-sm-12 col-xs-12">
                        <div class="pagination-box text-center">
                            <a href="#"><span><i class="fa fa-angle-left" aria-hidden="true"></i></span></a>
                            <a href="#"><span class="active-red">1</span></a>
                            <a href="#"><span>2</span></a>
                            <a href="#"><span>3</span></a>
                            <a href="#"><span>4</span></a>
                            <a href="#"><span>5</span></a>
                            <a href="#"><span><i class="fa fa-angle-right" aria-hidden="true"></i></span></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- //***Deals-List End***// -->
        <div class="clear"></div>
       <?php include "footer.php" ?>
    </body>

<!-- Mirrored from preview.yrthemes.com/thanks-giving/deals-list.php by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 22 Dec 2017 14:58:42 GMT -->
</html>