<?php include "header.php"; ?>
        <div class="breadcrumb-section">
            <div class="breadcrumb-text">
                <div class="container">
                    <div class="row">
                        <div class="col-md-12 col-sm-12 col-xs-12">
                            <div class="breadcrumb-text padTB100">
                                <h3><span>coupons</span></h3>
                                <ul class="breadcrumb-list">
                                    <li><a href="index-2.php">home</a></li>
                                    <li><a href="#">coupons list</a></li>
                                    <li><a href="#">sidebar</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- //***Breadcrumb-Section End***// -->
        <!-- //***Coupon-List-Sidebar Start***// -->
        <div class="coupons bg padTB60">
            <div class="container">
                <div class="row">
                    <div class="col-md-9 col-sm-8 col-xs-12">
                        <div class="row">
                            <div class="col-md-12 col-sm-12 col-xs-12">
                                <div class="couponss marB30">
                                    <div class="col-md-4 col-sm-5 col-xs-12 box-r">
                                        <div class="box-b box-e boxx">
                                            <figure>
                                                <img src="assets/img/all/layer11.jpg" alt="">
                                            </figure>
                                        </div>
                                    </div>
                                    <div class="col-md-8 col-sm-7 col-xs-12 padL0 box-l">
                                        <div class="box-detail box-f">
                                            <div class="col-md-12 col-sm-12 col-xs-12">
                                                <div class="row">
                                                    <h4 class="hover"><a href="coupons-details.php">4% extra cash back $250 Offer On all new products</a></h4>
                                                    <h4 class="marB10 marT10">Stores <span class="grey-a">- amazon,snapdeal</span></h4>
                                                    <h4 class="marB10">expires :<span class="red"> 25-11-2017 </span></h4>
                                                </div>
                                            </div>
                                            <div class="col-md-12 col-sm-12 col-xs-12 marT10 text-left">
                                                <div class="row">
                                                    <a href="#" class="itg-btn box-btn black">5566778<span>get code</span></a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-12 col-sm-12 col-xs-12">
                                <div class="couponss marB30">
                                    <div class="col-md-4 col-sm-5 col-xs-12 box-r">
                                        <div class="box-b box-e boxx">
                                            <figure>
                                                <img src="assets/img/all/layer12.jpg" alt="">
                                            </figure>
                                        </div>
                                    </div>
                                    <div class="col-md-8 col-sm-7 col-xs-12 padL0 box-l">
                                        <div class="box-detail box-f">
                                            <div class="col-md-12 col-sm-12 col-xs-12">
                                                <div class="row">
                                                    <h4 class="hover"><a href="coupons-details.php">4% extra cash back $250 Offer On all new products</a></h4>
                                                    <h4 class="marB10 marT10">Stores <span class="grey-a">- amazon,snapdeal</span></h4>
                                                    <h4 class="marB10">expires :<span class="red"> 25-11-2017 </span></h4>
                                                </div>
                                            </div>
                                            <div class="col-md-12 col-sm-12 col-xs-12 marT10 text-left">
                                                <div class="row">
                                                    <a href="#" class="itg-btn box-btn black">5566778<span>get code</span></a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-12 col-sm-12 col-xs-12">
                                <div class="couponss marB30">
                                    <div class="col-md-4 col-sm-5 col-xs-12 box-r">
                                        <div class="box-b box-e boxx">
                                            <figure>
                                                <img src="assets/img/all/layer13.jpg" alt="">
                                            </figure>
                                        </div>
                                    </div>
                                    <div class="col-md-8 col-sm-7 col-xs-12 padL0 box-l">
                                        <div class="box-detail box-f">
                                            <div class="col-md-12 col-sm-12 col-xs-12">
                                                <div class="row">
                                                    <h4 class="hover"><a href="coupons-details.php">4% extra cash back $250 Offer On all new products</a></h4>
                                                    <h4 class="marB10 marT10">Stores <span class="grey-a">- amazon,snapdeal</span></h4>
                                                    <h4 class="marB10">expires :<span class="red"> 25-11-2017 </span></h4>
                                                </div>
                                            </div>
                                            <div class="col-md-12 col-sm-12 col-xs-12 marT10 text-left">
                                                <div class="row">
                                                    <a href="#" class="itg-btn box-btn black">5566778<span>get code</span></a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-12 col-sm-12 col-xs-12">
                                <div class="couponss marB30">
                                    <div class="col-md-4 col-sm-5 col-xs-12 box-r">
                                        <div class="box-b box-e boxx">
                                            <figure>
                                                <img src="assets/img/all/layer9.jpg" alt="">
                                            </figure>
                                        </div>
                                    </div>
                                    <div class="col-md-8 col-sm-7 col-xs-12 padL0 box-l">
                                        <div class="box-detail box-f">
                                            <div class="col-md-12 col-sm-12 col-xs-12">
                                                <div class="row">
                                                    <h4 class="hover"><a href="coupons-details.php">4% extra cash back $250 Offer On all new products</a></h4>
                                                    <h4 class="marB10 marT10">Stores <span class="grey-a">- amazon,snapdeal</span></h4>
                                                    <h4 class="marB10">expires :<span class="red"> 25-11-2017 </span></h4>
                                                </div>
                                            </div>
                                            <div class="col-md-12 col-sm-12 col-xs-12 marT10 text-left">
                                                <div class="row">
                                                    <a href="#" class="itg-btn box-btn black">5566778<span>get code</span></a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-12 col-sm-12 col-xs-12">
                                <div class="couponss marB30">
                                    <div class="col-md-4 col-sm-5 col-xs-12 box-r">
                                        <div class="box-b box-e boxx">
                                            <figure>
                                                <img src="assets/img/all/layer10.jpg" alt="">
                                            </figure>
                                        </div>
                                    </div>
                                    <div class="col-md-8 col-sm-7 col-xs-12 padL0 box-l">
                                        <div class="box-detail box-f">
                                            <div class="col-md-12 col-sm-12 col-xs-12">
                                                <div class="row">
                                                    <h4 class="hover"><a href="coupons-details.php">4% extra cash back $250 Offer On all new products</a></h4>
                                                    <h4 class="marB10 marT10">Stores <span class="grey-a">- amazon,snapdeal</span></h4>
                                                    <h4 class="marB10">expires :<span class="red"> 25-11-2017 </span></h4>
                                                </div>
                                            </div>
                                            <div class="col-md-12 col-sm-12 col-xs-12 marT10 text-left">
                                                <div class="row">
                                                    <a href="#" class="itg-btn box-btn black">5566778<span>get code</span></a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-12 col-sm-12 col-xs-12">
                                <div class="couponss marB30">
                                    <div class="col-md-4 col-sm-5 col-xs-12 box-r">
                                        <div class="box-b box-e boxx">
                                            <figure>
                                                <img src="assets/img/all/layer11.jpg" alt="">
                                            </figure>
                                        </div>
                                    </div>
                                    <div class="col-md-8 col-sm-7 col-xs-12 padL0 box-l">
                                        <div class="box-detail box-f">
                                            <div class="col-md-12 col-sm-12 col-xs-12">
                                                <div class="row">
                                                    <h4 class="hover"><a href="coupons-details.php">4% extra cash back $250 Offer On all new products</a></h4>
                                                    <h4 class="marB10 marT10">Stores <span class="grey-a">- amazon,snapdeal</span></h4>
                                                    <h4 class="marB10">expires :<span class="red"> 25-11-2017 </span></h4>
                                                </div>
                                            </div>
                                            <div class="col-md-12 col-sm-12 col-xs-12 marT10 text-left">
                                                <div class="row">
                                                    <a href="#" class="itg-btn box-btn black">5566778<span>get code</span></a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-12 col-sm-12 col-xs-12">
                                <div class="couponss marB30">
                                    <div class="col-md-4 col-sm-5 col-xs-12 box-r">
                                        <div class="box-b box-e boxx">
                                            <figure>
                                                <img src="assets/img/all/layer12.jpg" alt="">
                                            </figure>
                                        </div>
                                    </div>
                                    <div class="col-md-8 col-sm-7 col-xs-12 padL0 box-l">
                                        <div class="box-detail box-f">
                                            <div class="col-md-12 col-sm-12 col-xs-12">
                                                <div class="row">
                                                    <h4 class="hover"><a href="coupons-details.php">4% extra cash back $250 Offer On all new products</a></h4>
                                                    <h4 class="marB10 marT10">Stores <span class="grey-a">- amazon,snapdeal</span></h4>
                                                    <h4 class="marB10">expires :<span class="red"> 25-11-2017 </span></h4>
                                                </div>
                                            </div>
                                            <div class="col-md-12 col-sm-12 col-xs-12 marT10 text-left">
                                                <div class="row">
                                                    <a href="#" class="itg-btn box-btn black">5566778<span>get code</span></a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
							<div class="col-md-12 col-sm-12 col-xs-12 hidden-lg hidden-md hidden-xs">
								<div class="pagination-box text-left">
									<a href="#"><span><i class="fa fa-angle-left" aria-hidden="true"></i></span></a>
									<a href="#"><span class="active-red">1</span></a>
									<a href="#"><span>2</span></a>
									<a href="#"><span>3</span></a>
									<a href="#"><span>4</span></a>
									<a href="#"><span>5</span></a>
									<a href="#"><span><i class="fa fa-angle-right" aria-hidden="true"></i></span></a>
								</div>
							</div>
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-4 col-xs-12">
                        <div class="row">
                            <div class="col-md-12 col-sm-12 col-xs-12">
                                <div class="search-bar">
                                    <div class="col-md-12 col-sm-12 col-xs-12">
                                        <div class="search_bar">
                                            <input type="text" name="search" placeholder="Search..">
                                            <button type="submit"><i class="fa fa-search" aria-hidden="true"></i></button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-12 col-sm-12 col-xs-12">
                                <div class="blog">
                                    <div id="blog" class="owl-carousel owlCarousel marT30">
                                        <div class="item">
                                            <div class="col-md-12 col-sm-12 col-xs-12">
                                                <div class="row">
                                                    <figure>
                                                        <img src="assets/img/blog/blog1.jpg" alt="">
                                                    </figure>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="item">
                                            <div class="col-md-12 col-sm-12 col-xs-12">
                                                <div class="row">
                                                    <figure>
                                                        <img src="assets/img/blog/blog-a.jpg" alt="">
                                                    </figure>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="item">
                                            <div class="col-md-12 col-sm-12 col-xs-12">
                                                <div class="row">
                                                    <figure>
                                                        <img src="assets/img/blog/blog-b.jpg" alt="">
                                                    </figure>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="blog-a">
                                    <p>Colorful Furnimart With High Up To 70% Discount On All Stores</p>
                                </div>
                            </div>
                            <div class="col-md-12 col-sm-12 col-xs-12">
                                <div class="latest-tweet marT20">
                                    <h4 class="red capital marB10">Latest tweets</h4>
                                    <h5 class="marB5"><i class="fa fa-twitter red" aria-hidden="true"></i> @Blackfriday.com</h5>
                                    <p>Lorem ipsum dolor sit acons tuadip iscing elit Fusce</p>
                                    <span class="red">www.itg.Com</span> 
                                    <p>4 hour ago</p>
                                    <h4 class="red capital marB10 marT30">Latest tweets</h4>
                                    <h5 class="marB5"><i class="fa fa-twitter red" aria-hidden="true"></i> @Blackfriday.com</h5>
                                    <p>Lorem ipsum dolor sit acons tuadip iscing elit Fusce</p>
                                    <span class="red">www.itg.Com</span> 
                                    <p>4 hour ago</p>
                                </div>
                            </div>
                            <div class="col-md-12 col-sm-12 col-xs-12">
                                <div class="trending-offers marT20">
                                    <h4 class="red capital marB10"><a href="#">Trending Offers</a></h4>
                                    <div class="trending">
                                        <div class="col-md-4 col-sm-4 col-xs-12">
                                            <div class="row">
                                                <figure>
                                                    <img src="assets/img/blog/blog2.jpg" alt="">
                                                </figure>
                                            </div>
                                        </div>
                                        <div class="col-md-8 col-sm-8 col-xs-12">
                                            <div class="row">
                                                <h5><a href="#">Flate 25% OFF on Men’s Clothing</a></h5>
                                                <h5 class="red"><a href="#"><span>Read More</span></a></h5>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="trending">
                                        <div class="col-md-4 col-sm-4 col-xs-12">
                                            <div class="row">
                                                <figure>
                                                    <img src="assets/img/blog/blog3.jpg" alt="">
                                                </figure>
                                            </div>
                                        </div>
                                        <div class="col-md-8 col-sm-8 col-xs-12">
                                            <div class="row">
                                                <h5><a href="#">Flate 25% OFF on Men’s Clothing</a></h5>
                                                <h5 class="red"><a href="#"><span>Read More</span></a></h5>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="trending">
                                        <div class="col-md-4 col-sm-4 col-xs-12">
                                            <div class="row">
                                                <figure>
                                                    <img src="assets/img/blog/blog4.jpg" alt="">
                                                </figure>
                                            </div>
                                        </div>
                                        <div class="col-md-8 col-sm-8 col-xs-12">
                                            <div class="row">
                                                <h5><a href="#">Flate 25% OFF on Men’s Clothing</a></h5>
                                                <h5 class="red"><a href="#"><span>Read More</span></a></h5>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="trending">
                                        <div class="col-md-4 col-sm-4 col-xs-12">
                                            <div class="row">
                                                <figure>
                                                    <img src="assets/img/blog/blog5.jpg" alt="">
                                                </figure>
                                            </div>
                                        </div>
                                        <div class="col-md-8 col-sm-8 col-xs-12">
                                            <div class="row">
                                                <h5><a href="#">Flate 25% OFF on Men’s Clothing</a></h5>
                                                <h5 class="red"><a href="#"><span>Read More</span></a></h5>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-12 col-sm-12 col-xs-12">
                                <div class="tags marT20">
                                    <h4 class="red marB10 capital"><a href="#">Popular Tags</a></h4>
                                    <ul>
                                        <li><a href="#">art</a></li>
                                        <li><a href="#">paint</a></li>
                                        <li><a href="#">floor</a></li>
                                        <li><a href="#">exterior</a></li>
                                        <li><a href="#">interrior</a></li>
                                        <li><a href="#">paint</a></li>
                                        <li><a href="#">floor</a></li>
                                        <li><a href="#">industry</a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-12 col-sm-12 col-xs-12 hidden-sm">
                        <div class="pagination-box text-left">
                            <a href="#"><span><i class="fa fa-angle-left" aria-hidden="true"></i></span></a>
                            <a href="#"><span class="active-red">1</span></a>
                            <a href="#"><span>2</span></a>
                            <a href="#"><span>3</span></a>
                            <a href="#"><span>4</span></a>
                            <a href="#"><span>5</span></a>
                            <a href="#"><span><i class="fa fa-angle-right" aria-hidden="true"></i></span></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- //***Coupon-List-Sidebar End***// -->
        <div class="clear"></div>
       <?php include "footer.php" ?>
    </body>

<!-- Mirrored from preview.yrthemes.com/thanks-giving/coupon-list-sidebar.php by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 22 Dec 2017 14:59:23 GMT -->
</html>