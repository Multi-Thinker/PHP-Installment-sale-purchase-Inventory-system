<?php
$functionsINNER=TRUE;
$functions['TRADITIONAL']=1;
include "config.php"; 
$userInfo = userInfo();
$today = checkRequest("start_date");
$end = checkRequest("end_date");
if($today==''){
	$today = date("Y-m-d");
}
if($end == ''){
	$end   = date("Y-m-d",strtotime($today."-7 days"));	
}
$to_day = date("d");
?>
<?php include "tHeader.php"; ?>
<?php 
if(isset($_REQUEST['wrong_token'])){
	echo "provided token was :".$_SESSION['provided_csrf_token']." where the token should be: ".$_SESSION['old_csrf_token']." current token is: ".$_SESSION['csrf_token'];
}
?>
<h1 class="page-header">Overview</h1>  
<?php 

$query = mysqli_query($con, "select t.dispute, t.client_id, p.id as party_id, po.id as product_id, p.name,t.invoice, po.alias,IFNULL((select sum(th.amount) from transaction_history th where th.pid=t.party_id AND th.tid=t.id AND th.dispute='0'),0) as other_paid, t.total_amount, t.paid_amount, t.id as tid, t.type, t.status, cast(t.created_at as date) as created_at from transactions t, parties p, products po where p.id=t.party_id and po.id=t.product_id and (t.type='1' or t.type='2') and cast(t.created_at as date)>='{$today}' and cast(t.created_at as date)<='{$end}'");

$record = mysqli_query($con, "select (select count(id) from clients where cast(created_at as date)>='{$today}' and cast(created_at as date)<='{$end}') as clients, (select count(id) from transactions where type='2' and cast(created_at as date)>='{$today}' and cast(created_at as date)<='{$end}') as sales, (select count(id) from parties where cast(updated_at as date)>='{$today}' and cast(updated_at as date)<='{$end}') as parties");
$records = mysqli_fetch_assoc($record);
?>

	<div class="row">
		*Records as per last week/selection
                    <div class="col-lg-3 col-md-6">
                        <div class="panel panel-primary">
                            <div class="panel-heading">
                                <div class="row">
                                    <div class="col-xs-3">
                                        <i class="fa fa-comments fa-5x"></i>
                                    </div>
                                    <div class="col-xs-9 text-right">
                                        <div class="huge"><?=$records['clients']?></div>
                                        <div>New Clients!</div>
                                    </div>
                                </div>
                            </div>
                            <a href="Clients.php">
                                <div class="panel-footer">
                                    <span class="pull-left">View Details</span>
                                    <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>

                                    <div class="clearfix"></div>
                                </div>
                            </a>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6">
                        <div class="panel panel-green">
                            <div class="panel-heading">
                                <div class="row">
                                    <div class="col-xs-3">
                                        <i class="fa fa-shopping-cart fa-5x"></i>
                                    </div>
                                    <div class="col-xs-9 text-right">
                                        <div class="huge"><?=$records['sales']?></div>
                                        <div>New Sales!</div>
                                    </div>
                                </div>
                            </div>
                            <a href="Sales.php">
                                <div class="panel-footer">
                                    <span class="pull-left">View Details</span>
                                    <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>

                                    <div class="clearfix"></div>
                                </div>
                            </a>
                        </div>
                    </div>

                    <div class="col-lg-3 col-md-6">
                        <div class="panel panel-red">
                            <div class="panel-heading">
                                <div class="row">
                                    <div class="col-xs-3">
                                        <i class="fa fa-support fa-5x"></i>
                                    </div>
                                    <div class="col-xs-9 text-right">
                                        <div class="huge"><?=$records['parties']?></div>
                                        <div>New Parties!</div>
                                    </div>
                                </div>
                            </div>
                            <a href="Parties.php">
                                <div class="panel-footer">
                                    <span class="pull-left">View Details</span>
                                    <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>

                                    <div class="clearfix"></div>
                                </div>
                            </a>
                        </div>
                    </div>
                </div>
<a href="javascript:void(0)" class="toggler">Custom Search</a>

	<form method="GET" class="selector" style="display:none;">
<!-- 	<label for="selectType">Select Type:</label>
	<select name="selectType" id="selectType" class="selectType form-control">
		<option value="0" selected="selected">Purchase</option>
		<option value="1">Sale</option>
	</select> -->
	<label for="stimeRange">Start Date</label>
	<input type="text" id="stimeRange" class="sdate form-control" name="start_date" placeholder="YYYY-MM-DD" />
	<label for="etimeRange">End Date</label>
	<input type="text" id="etimeRange" class="edate form-control" name="end_date" placeholder="YYYY-MM-DD" />
	<button type="submit" role="submit" class="btn btn-primary goSearch">Search</button> 
	</form>

<div class="row">
                    <div class="col-lg-8">
                        <div class="panel panel-default">
                            <div class="panel-heading">
                                <i class="fa fa-bar-chart-o fa-fw"></i> Transactions by last week
                            </div>
                            <!-- /.panel-heading -->
                            <div class="panel-body">
                                <div id="morris-area-chart"></div>
                            </div>
                            <!-- /.panel-body -->
                        </div>
                      </div>

                    <!-- /.col-lg-8 -->
                    <div class="col-lg-4">
                        <div class="panel panel-default">
                            <div class="panel-heading">
                                <i class="fa fa-bell fa-fw"></i> Notifications Panel
                            </div>
                            <!-- /.panel-heading -->
                            <div class="panel-body">
                                <div class="list-group">
                                  <!--   <a href="#" class="list-group-item">
                                        <i class="fa fa-shopping-cart fa-fw"></i> New Order Placed
                                            <span class="pull-right text-muted small"><em>9:49 AM</em>
                                            </span>
                                    </a> -->
                                    <?php 
                                    	$remindQ = mysqli_query($con,"SELECT installment_day, invoice,id,client_id from transactions where type='2' and installment_day<='{$to_day}' and status='0'");
                                    	while($rQ = mysqli_fetch_assoc($remindQ)){
                                    ?>

                                    <a href="addFunds.php?tid=<?=$rQ['id']?>&type=sales&client=<?=$rQ['client_id']?>&invoice=<?=$rQ['invoice']?>" class="list-group-item">
                                        <i class="fa fa-money fa-fw"></i>Reminder for Invoice# <?=$rQ['invoice']?> 
                                            <span class="pull-right text-muted small"><em>Due on: <?=$rQ['installment_day']?> of every month</em>
                                            </span>
                                    </a>
                                    <br>
                                    <?php } ?>
                                </div>
                                
                            </div>
                            <!-- /.panel-body -->
                        </div>
                    </div>
                    <!-- /.col-lg-4 -->
                </div>
                <div class="row">
                	 <div class="panel panel-default">
                            <div class="panel-heading">
                                <i class="fa fa-bar-chart-o fa-fw"></i> Report
                            </div>
                            <!-- /.panel-heading -->
                <div class="panel-body">
						<table class='table table-hover sort_table' style="margin:auto;width:100%" width="100%">
							<thead>
								<tr>
									<th>Invoice</th>
									<th>Date</th>
									<th>Party</th>
									<th>Product</th>
									<th>Type</th>
									<th>Total Amount</th>
									<th>Total Paid</th>

									<th>Status</th>
									<th>Action</th>
								</tr>
							</thead>
							<tbody>
							<?php 
							while($result = mysqli_fetch_assoc($query)){
								$tid = $result['tid'];
							?>
								<tr>
									<td><?=$result['invoice']?></td>
									<td><?=$result['created_at']?></td>
									<td><?=dbOUT($result['name'])?></td>
									<td><?=dbOUT($result['alias'])?></td>
									<td>
									<?php 
									$type = "purchase";
									$client = '';
									if($result['type']=="1"){
										echo "purchases";
									}
									if($result['type']=="2"){
										echo "Sale";
									if($result['client_id']!=''){
										$client = "&client=true";
										$type = "sales";
										}
									}
									?>
									</td>
									<td><?=$result['total_amount']?></td>
									<td><?=$result['other_paid']?></td>
									<td>
									<?php
									if($result['dispute']=='0'){
										if($result['status']=='0'){
											echo "In Progress";
										}
										else if($result['status']=='1'){
											echo "Fulfilled";
										}else{
											echo "Sold";
											}
									}else{
										echo "Disputed";
									}
									?>
									</td>
									<td>
										<a href="addFunds.php?tid=<?=$tid?>&type=<?=$type?>&invoice=<?=$result['invoice']?><?=$client?>">View</a>
										</td>
								</tr>
							<?php 
							}
							?>
							</tbody>
						</table>
                     </div>
                            <!-- /.panel-body -->
               </div>
        </div>




<?php include "tFooter.php"; ?>
 <script src="../js/raphael.min.js"></script>
 <script src="../js/morris.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.13/jquery.mask.min.js"></script>
<?php 

$AreaQ = mysqli_query($con,"SELECT (select count(pt.id) from transactions pt WHERE cast(pt.created_at as date)>='{$today}' AND cast(pt.created_at as date)<='{$end}' and pt.type='1') as purchase, cast(created_at as date) as period, (select count(st.id) from transactions st where cast(st.created_at as date)>='".$today."' and cast(st.created_at as date)<='".$end."' and st.type='2') as sales from transactions group by cast(created_at as date)");
while($re = mysqli_fetch_assoc($AreaQ)){
	$result[] = $re;
}

?>
<script>
	$(function(){
		$(".sdate,.edate").mask("0000-00-00");
		$(".toggler").click(function(){
			$(".selector").slideToggle();
		});
		     Morris.Area({
		        element: 'morris-area-chart',
		        data: <?=json_encode($result)?>,
		        xkey: ['period'],
		        ykeys:  ['sales', 'purchase'],
		        labels: ['Sales', 'Purchase'],
		        pointSize: 1,
		        hideHover: 'auto',
		        resize: true
		    });
	});
</script>