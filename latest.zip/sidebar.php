 <div class="navbar-default sidebar" role="navigation">
            <div class="sidebar-nav navbar-collapse">
                <ul class="nav" id="side-menu">
                    <li>
                        <a href="./index.php"><i class="fa fa-dashboard fa-fw"></i> Dashboard</a>
                    </li>
                     <li>
                        <a href="./Parties.php"></i> Manage Parties</a>
                    </li>
                    <li>
                        <a href="./Clients.php"></i> Clients</a>
                    </li>
                    <li>
                        <a href="./Companies.php"></i> Manage Companies</a>
                    </li>
                    <li>
                        <a href="./ProductType.php"></i>Product Types</a>
                    </li>
                    <li>
                        <a href="./ProductModels.php"></i>Product Models</a>
                    </li>
                    <li>
                        <a href="./Products.php"></i>Products</a>
                    </li>
                    <li>
                        <a href="./Purchase.php"></i>Purchase</a>
                    </li>
                    <li>
                        <a href="./Sales.php"></i>Sale</a>
                    </li>
                  <!--   <li>
                        <a href="./Report.php"></i>Report</a>
                    </li> -->
                </ul>
            </div>
        </div>