<?php 
//DONT EDIT
//SAVE.PHP
$inner = TRUE;
$functionsINNER = TRUE;
$functions['GLOBAL_ONLY'] = 1;
$functions['USER_LEVEL_ONLY'] = 1;
$functions['DB_ONLY'] = 1;
$CSRFrequired = 1;
include "config.php";
$userInfo = userInfo();
$pageFunction = "";
if(isset($_REQUEST['function']) && $_REQUEST['function']!=''){
	$pageFunction = $_REQUEST['function'];
}


/************ FUNCTION BODY ********************/
switch ($pageFunction) {

	/***** PARTY PAGE *********/
	case 'addParty':
			$name  = dbIN($_REQUEST['bname']);
			$phone = dbIN($_REQUEST['bphone']);
			$email = dbIN($_REQUEST['bemail']);
			$fax   = dbIN($_REQUEST['bfax']);
			$addr  = dbIN($_REQUEST['baddr']);
			mysqli_query($con,"INSERT INTO parties (name,phone,email,fax,address) VALUES ('".$name."','".$phone."','".$email."','{$fax}','{$addr}')") or die(mysqli_error($con));
		  set_message("Party ADDED");
		  goBack();
	break;
	case 'updateParty':
		  $name  = dbIN($_REQUEST['bname']);
		  $phone = dbIN($_REQUEST['bphone']);
		  $email = dbIN($_REQUEST['bemail']);
		  $fax   = dbIN($_REQUEST['bfax']);
		  $addr  = dbIN($_REQUEST['baddr']);
		  $id    = dbIN($_REQUEST['UID']);
		  mysqli_query($con,"UPDATE parties SET name='{$name}', phone='{$phone}', email='{$email}', fax='{$fax}', address='{$addr}' WHERE id='{$id}' AND status='1'");
		  set_message("Party UPDATED");
		  goBack();
	break;

	/*********** COMPANY PAGE ******************/
	case 'addCompany':
		$name  = dbIN($_REQUEST['bname']);
		$phone = dbIN($_REQUEST['bphone']);
		$addr  = dbIN($_REQUEST['baddr']);
		$fax   = dbIN($_REQUEST['bfax']);
		$owner = dbIN($_REQUEST['bowner']);
		mysqli_query($con,"INSERT INTO companies (name,phone,address,fax,owner) VALUES ('{$name}','{$phone}','{$addr}','{$fax}','{$owner}')");
		set_message("Company ADDED");
		goBack();
	break;	
	case 'updateCompany':
		$name  = dbIN($_REQUEST['bname']);
		$phone = dbIN($_REQUEST['bphone']);
		$addr  = dbIN($_REQUEST['baddr']);
		$fax   = dbIN($_REQUEST['bfax']);
		$owner = dbIN($_REQUEST['bowner']);
		$id    = dbIN($_REQUEST['UID']);
		mysqli_query($con,"UPDATE companies SET name = '{$name}',phone='{$phone}',address='{$addr}',fax='{$fax}',owner='{$owner}' WHERE id='{$id}'");
		set_message("Company UPDATED");
		goBack();
	break;
	/****************** PRODUCT TYPE **********************/
	case 'addProductType':
		$name  = dbIN($_REQUEST['bname']);
		$cid   = dbIN($_REQUEST['company']);
		mysqli_query($con,"INSERT INTO product_types (name,company_id) VALUES ('{$name}','{$cid}')");
		set_message("Product Type ADDED");
		goBack();
	break;
	case 'updateProductType':
		$name  = dbIN($_REQUEST['bname']);
		$cid   = dbIN($_REQUEST['company']);
		$id    = dbIN($_REQUEST['UID']);
		mysqli_query($con,"UPDATE product_types SET name = '{$name}', company_id='{$cid}' WHERE id='{$id}'");
		set_message("Product Type UPDATED");
		goBack();
	break;
	/***************** PRODUCT MODEL ***************************/
	case 'addProductModel':
		$name  = dbIN($_REQUEST['bname']);
		$pid   = dbIN($_REQUEST['btype']);

		mysqli_query($con,"INSERT INTO product_models (name,product_type_id) VALUES ('{$name}','{$pid}')");
		set_message("Product Model ADDED");
		goBack();
	break;
	case 'updateProductModel':
		$name  = dbIN($_REQUEST['bname']);
		$pid   = dbIN($_REQUEST['btype']);
		$id    = dbIN($_REQUEST['UID']);
		mysqli_query($con,"UPDATE product_models set name='{$name}', product_type_id='{$pid}' WHERE id='{$id}'");
		set_message("Product Model UPDATED");
		goBack();
	break;	
	/**************** Main Product ***********************/
	case 'addMainProduct':
		$company = dbIN($_REQUEST['company']);
		$type    = dbIN($_REQUEST['Type']);
		$model   = dbIN($_REQUEST['Model']);
		$price   = dbIN($_REQUEST['price']);
		$typeName = dbIN($_REQUEST['tname']);
		$modelName = dbIN($_REQUEST['mname']);
		$companyName = dbIN($_REQUEST['cname']);
		$alias   = $companyName." ".$typeName." ".$modelName;

		mysqli_query($con,"INSERT INTO products (alias,company_id,product_type_id,product_model_id,unit_price) VALUES 
			('{$alias}','{$company}','{$type}','{$model}','{$price}')");
		set_message("Product added");
		goBack();
	break;
	case 'updateMainProduct':
		$company = dbIN($_REQUEST['company']);
		$type    = dbIN($_REQUEST['Type']);
		$model   = dbIN($_REQUEST['Model']);
		$price   = dbIN($_REQUEST['price']);
		$typeName = dbIN($_REQUEST['tname']);
		$modelName = dbIN($_REQUEST['mname']);
		$companyName = dbIN($_REQUEST['cname']);
		$alias   = $companyName." ".$typeName." ".$modelName;
		$id     = dbIN($_REQUEST['UID']);

		mysqli_query($con, "UPDATE products set alias='{$alias}',
			company_id='{$company}', product_type_id='{$type}',
			product_model_id='{$model}', unit_price='{$price}' WHERE id='{$id}'");
		set_message("Product Updated");
		goBack();
	break;
	/************ WRONG OR EMPTY REQUESTS ***********/
	default:
		set_message("You are not allowed to perform that action");
		goBack();
	break;
}

?>