<?php
$functionsINNER=TRUE;
$functions['TRADITIONAL']=1;
include "config.php"; 
$userInfo = userInfo();
?>
<?php include "tHeader.php"; ?>

<h1 class="page-header">Page Title</h1>  


<?php include "tFooter.php"; ?>