<footer>
<!-- jQuery -->
<script src="js/jquery.min.js"></script>
<!-- Bootstrap Core JavaScript -->
<script src="js/bootstrap.min.js"></script>
<!-- Metis Menu Plugin JavaScript -->
<script src="js/metisMenu.min.js"></script>
<!-- Custom Theme JavaScript -->
<script src="js/startmin.js"></script>

<script src="js/dataTables/jquery.dataTables.min.js"></script>
<script>
	function getConfirmation(str,id){
		var conf = confirm(str);
		if(conf==false){
			return false;
		}else{
			window.location.href="?action=delete&UID="+id;
			return true;
		}
	}
	$(".sort_table").dataTable();
</script>
</footer>
</html>